﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManager_1.Shared.Domain
{
    public class UserTask : BaseDomainModel
    {
        public string TaskName { get; set; }
        public Boolean IsCompleted { get; set; }

        public DateTime DueDate { get; set; }

    }
}
